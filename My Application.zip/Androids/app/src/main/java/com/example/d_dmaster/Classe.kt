package com.example.d_dmaster

data class Classe(val nome: String, val bonusAtributos: Map<String, Int>)
