package com.example.d_dmaster

interface DistribuicaoAtributosStrategy {
    fun distribuir(personagem: Personagem, pontos: Int)
}
